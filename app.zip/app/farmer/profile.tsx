import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, StyleSheet, ActivityIndicator } from "react-native";
import { Link } from "expo-router";

export default function Profile() {
  const [farmer, setFarmer] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchFarmer = async () => {
      try {
        const res = await fetch("https://your-backend.com/api/farmer/profile"); // Your backend endpoint
        const data = await res.json();
        setFarmer(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchFarmer();
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#0A364F" />
      </View>
    );
  }

  if (!farmer) {
    return (
      <View style={styles.loading}>
        <Text style={{ color: "#6b7280" }}>Failed to load profile</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.headerTxt}>My Profile</Text>

        <View style={styles.card}>
          <Text style={styles.label}>Name</Text>
          <Text style={styles.value}>{farmer.name}</Text>

          <Text style={styles.label}>Email ID</Text>
          <Text style={styles.value}>{farmer.email}</Text>

          <Text style={styles.label}>Farmer ID</Text>
          <Text style={styles.value}>{farmer.farmer_id}</Text>

          <Text style={styles.label}>Address</Text>
          <Text style={styles.value}>{farmer.address}</Text>

          <Text style={styles.label}>Phone Number</Text>
          <Text style={styles.value}>{farmer.phone}</Text>
        </View>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Link href="/farmer" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>🏠</Text>
            <Text style={styles.activeLabel}>Home</Text>
          </View>
        </Link>

        <Link href="/farmer/dosage-log" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>📋</Text>
            <Text style={styles.label}>Log</Text>
          </View>
        </Link>

        <Link href="/farmer/alerts" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>🔔</Text>
            <Text style={styles.label}>Alerts</Text>
          </View>
        </Link>

        <Link href="/farmer/profile" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>👤</Text>
            <Text style={styles.activeLabel}>Profile</Text>
          </View>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  scroll: { padding: 16, gap: 16 },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },
  card: { backgroundColor: "white", borderRadius: 16, padding: 20, shadowOpacity: 0.1, shadowRadius: 3 },
  label: { fontSize: 14, color: "#6b7280", fontWeight: "500", marginTop: 12 },
  value: { fontSize: 16, color: "#0A364F", marginTop: 4 },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
});
