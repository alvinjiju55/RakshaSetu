import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { Link, useRouter } from "expo-router";

export default function FarmerLogin() {
  const router = useRouter();

  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async () => {
    // 1. Client-side validation
    if (!emailOrPhone || !password) {
      Alert.alert("Error", "Please enter email/phone and password");
      return;
    }

    // 2. Call backend API (replace URL with your actual endpoint)
    try {
      const response = await fetch("https://your-backend.com/api/farmer/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ emailOrPhone, password }),
      });
      const data = await response.json();

      if (response.ok) {
        // Login successful → navigate to dashboard
        router.push("/farmer"); // Correct path for FarmerDashboard
      } else {
        Alert.alert("Error", data.message || "Login failed");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Network error. Please try again.");
    }
  };

  const handleForgotPassword = () => {
    // Placeholder for forgot password flow
    Alert.alert("Forgot Password", "Password reset flow goes here");
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        {/* Centered Card */}
        <View style={styles.card}>
          <Text style={styles.title}>Farmer Login</Text>

          <TextInput
            style={styles.input}
            placeholder="Email or Phone Number"
            value={emailOrPhone}
            onChangeText={setEmailOrPhone}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            style={styles.input}
            placeholder="Password"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity onPress={handleForgotPassword}>
            <Text style={styles.forgotPasswordText}>Forgot Password?</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.button} onPress={handleLogin}>
            <Text style={styles.buttonText}>Login</Text>
          </TouchableOpacity>

          <Text style={styles.orText}>Don't have an account?</Text>
          <Link href="/farmer/signup" asChild>
            <TouchableOpacity style={{ ...styles.button, ...styles.signupButton }}>
              <Text style={{ ...styles.buttonText, color: "#16a34a" }}>Sign Up</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fcf8" },
  scrollContainer: { flexGrow: 1, justifyContent: "center", alignItems: "center", padding: 16 },
  card: {
    width: "100%",
    maxWidth: 400,
    backgroundColor: "#ffffff",
    padding: 24,
    borderRadius: 16,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5, // Android shadow
  },
  title: { fontSize: 24, fontWeight: "700", marginBottom: 24, color: "#111827", textAlign: "center" },
  input: {
    width: "100%",
    backgroundColor: "#f3f4f6",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    marginBottom: 16,
    fontSize: 16,
    color: "#111827",
  },
  button: { backgroundColor: "#16a34a", borderRadius: 12, paddingVertical: 12, alignItems: "center", marginBottom: 12, width: "100%" },
  signupButton: { backgroundColor: "#fefcf8", borderWidth: 1, borderColor: "#16a34a" },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  forgotPasswordText: { color: "#2563eb", fontSize: 14, textAlign: "right", width: "100%", marginBottom: 16 },
  orText: { textAlign: "center", marginVertical: 8, color: "#6b7280", fontSize: 14 },
});
