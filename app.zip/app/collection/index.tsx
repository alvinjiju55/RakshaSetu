// CollectionCenterDashboard.tsx
import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
  TextInput,
  Alert,
  Platform,
  FlatList,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";
import * as ImagePicker from "expo-image-picker";
import { BarCodeScanner } from "expo-barcode-scanner";

/**
 * Types
 */
type Animal = {
  id: string;
  name: string;
  lastDrug: string;
  withdrawalDaysLeft: number;
};

type Farmer = {
  id: string;
  name: string;
  animals: Animal[];
  badge?: { residueSafe: boolean; badgeId?: string }; // from QR
  flagged?: boolean;
  incentivePenalty?: number; // percent penalty
};

type BatchRecord = {
  id: string; // same as produce id
  farmerId: string;
  type: "Milk" | "Meat";
  qrVerified: boolean;
  qrPayload?: any;
  photoUri?: string;
  aiSafe?: boolean | null;
  aiConfidence?: number | null;
  status?: "Accepted" | "Rejected" | "Pending";
  flagged?: boolean;
  timestamp: string;
};

/**
 * Dummy initial data (replace with real API)
 */
const INITIAL_FARMERS: Farmer[] = [
  {
    id: "F001",
    name: "Farmer A",
    animals: [
      { id: "C001", name: "Cow #123", lastDrug: "Drug A", withdrawalDaysLeft: 0 },
      { id: "C002", name: "Cow #124", lastDrug: "Drug B", withdrawalDaysLeft: 3 }, // withdrawal
    ],
  },
  {
    id: "F002",
    name: "Farmer B",
    animals: [
      { id: "C003", name: "Cow #223", lastDrug: "Drug C", withdrawalDaysLeft: 0 },
    ],
  },
];

/**
 * Main Component
 */
export default function CollectionCenterDashboard() {
  const [activeTab, setActiveTab] = useState<"Scan" | "Photos" | "Decision" | "Reports">("Scan");

  // data stores
  const [farmers, setFarmers] = useState<Farmer[]>(INITIAL_FARMERS);
  const [batches, setBatches] = useState<BatchRecord[]>([]);

  // QR scanner state
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [scanning, setScanning] = useState(false);

  // photo upload state
  const [photoUri, setPhotoUri] = useState<string>("");

  // load permissions
  useEffect(() => {
    (async () => {
      const { status } = await BarCodeScanner.requestPermissionsAsync();
      setHasCameraPermission(status === "granted");
    })();
  }, []);

  /***** Utility: detect suspicious farmer  *****/
  const isSuspiciousFarmer = (farmer: Farmer) => {
    // rule: farmer has >1 animal and at least one animal in withdrawal -> suspicious
    return farmer.animals.length > 1 && farmer.animals.some(a => a.withdrawalDaysLeft > 0);
  };

  /***** QR scan handler *****/
  const onBarCodeScanned = ({ data }: { data: string }) => {
    setScanning(false);
    // assume your QR encodes JSON: { farmerId: "...", badge: { residueSafe: true, badgeId: "..." } }
    // adapt parsing to your exact QR payload
    let payload: any = null;
    try {
      payload = JSON.parse(data);
    } catch (err) {
      // if QR is raw farmerId, fallback
      payload = { farmerId: data, badge: { residueSafe: false } };
    }

    const farmerId = payload.farmerId;
    const farmer = farmers.find(f => f.id === farmerId);
    if (!farmer) {
      Alert.alert("Unknown farmer", `Scanned farmerId ${farmerId} not in local list`);
      // Optionally create a new farmer entry or fetch from server
      return;
    }

    // attach badge info to farmer
    const updatedFarmers = farmers.map(f => f.id === farmerId ? { ...f, badge: payload.badge } : f);
    setFarmers(updatedFarmers);

    // create a new BatchRecord for this scan (simulate batch id)
    const newBatch: BatchRecord = {
      id: `B-${Date.now()}`,
      farmerId,
      type: "Milk",
      qrVerified: true,
      qrPayload: payload,
      status: "Pending",
      flagged: false,
      timestamp: new Date().toISOString(),
    };
    setBatches(prev => [newBatch, ...prev]);

    Alert.alert("QR scanned", `Farmer: ${farmer.name}\nBadge residueSafe: ${payload.badge?.residueSafe ? "Yes" : "No"}`);
  };

  /***** Photo picker and AI check (simulated) *****/
  const pickImageAndVerify = async (batchId: string) => {
    // ask permission and pick
    const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permission.granted) {
      Alert.alert("Permission denied", "Please grant photo permissions");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({ quality: 0.7, base64: false });
    if (!result.canceled && result.assets && result.assets.length > 0) {
      const uri = result.assets[0].uri;
      // update batch photo
      setBatches(prev => prev.map(b => b.id === batchId ? { ...b, photoUri: uri } : b));

      // run AI/CV check (simulate)
      simulateAIValidation(batchId, uri);
    }
  };

  const takePhotoAndVerify = async (batchId: string) => {
    const permissionCamera = await ImagePicker.requestCameraPermissionsAsync();
    if (!permissionCamera.granted) {
      Alert.alert("Permission denied", "Please grant camera permissions");
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 0.7, base64: false });
    if (!result.canceled && result.assets && result.assets.length > 0) {
      const uri = result.assets[0].uri;
      setBatches(prev => prev.map(b => b.id === batchId ? { ...b, photoUri: uri } : b));
      simulateAIValidation(batchId, uri);
    }
  };

  // Simulated AI/CV inference — replace with actual CV model or API
  const simulateAIValidation = (batchId: string, uri: string) => {
    // Simulate processing delay
    setTimeout(() => {
      const isSafe = Math.random() > 0.35; // 65% chance safe
      const confidence = Math.round((Math.random() * 20 + 80) * 10) / 10; // 80.0 - 100.0

      setBatches(prev => prev.map(b => {
        if (b.id !== batchId) return b;
        // find farmer and check QR badge
        const farmer = farmers.find(f => f.id === b.farmerId);
        const qrBadgeSafe = farmer?.badge?.residueSafe ?? false;

        // If QR badge said safe but AI says unsafe -> flag contradictions
        let flagged = false;
        let status: BatchRecord["status"] = isSafe ? "Accepted" : "Rejected";
        if (qrBadgeSafe && !isSafe) flagged = true;

        // Apply penalty if contradiction
        if (flagged) {
          setFarmers(prevFarmers => prevFarmers.map(f => {
            if (f.id !== b.farmerId) return f;
            return { ...f, flagged: true, incentivePenalty: (f.incentivePenalty || 0) + 10 }; // add 10% penalty
          }));
        }

        return {
          ...b,
          aiSafe: isSafe,
          aiConfidence: confidence,
          status,
          flagged
        };
      }));

      Alert.alert("AI Verification Complete", `Batch ${batchId}\nSafe: ${isSafe ? "Yes" : "No"}\nConfidence: ${confidence}%`);
    }, 800); // 800ms simulated
  };

  /***** Accept / Reject manual override (collector decision) *****/
  const acceptRejectBatch = (batchId: string, action: "Accept" | "Reject") => {
    setBatches(prev => prev.map(b => b.id === batchId ? { ...b, status: action === "Accept" ? "Accepted" : "Rejected" } : b));
    Alert.alert(`${action}ed`, `Batch ${batchId} ${action === "Accept" ? "accepted" : "rejected"} manually.`);
  };

  /***** Build and send compliance report (simulated) *****/
  const sendComplianceReport = () => {
    // Build summary
    const total = batches.length;
    const accepted = batches.filter(b => b.status === "Accepted").length;
    const rejected = batches.filter(b => b.status === "Rejected").length;
    const flagged = batches.filter(b => b.flagged).length;
    const report = {
      timestamp: new Date().toISOString(),
      total,
      accepted,
      rejected,
      flagged,
      details: batches.map(b => ({
        id: b.id,
        farmerId: b.farmerId,
        status: b.status,
        aiSafe: b.aiSafe,
        aiConfidence: b.aiConfidence,
        flagged: b.flagged
      }))
    };

    // Replace this with actual API call to regulator
    console.log("Sending compliance report to regulator:", report);
    Alert.alert("Compliance Report Sent", `Total: ${total}, Accepted: ${accepted}, Rejected: ${rejected}, Flagged: ${flagged}`);
  };

  /***** UI Render sections *****/
  const renderScanTab = () => (
    <ScrollView style={styles.scroll}>
      <View style={styles.card}>
        <Text style={styles.safeTitle}>Scan Farmer QR</Text>
        <Text style={styles.safeSub}>Open camera and scan the farmer's QR badge (Residue-Safe badge).</Text>

        <View style={{ marginTop: 12 }}>
          <TouchableOpacity
            style={styles.submitBtn}
            onPress={() => {
              if (hasCameraPermission === false) {
                Alert.alert("Camera permission required", "Enable camera permission from settings.");
                return;
              }
              setScanning(true);
            }}
          >
            <Text style={styles.submitTxt}>Open Camera to Scan QR</Text>
          </TouchableOpacity>
        </View>

        <Text style={{ marginTop: 12, color: "#6b7280" }}>
          Recently scanned batches:
        </Text>

        {batches.length === 0 ? <Text style={{ marginTop: 8, color: "#6b7280" }}>No scans yet.</Text> : (
          batches.map(b => (
            <View key={b.id} style={[styles.card, { marginTop: 12 }]}>
              <Text style={styles.bold}>Batch: {b.id}</Text>
              <Text style={{ marginTop: 4, color: "#6b7280" }}>Farmer: {farmers.find(f => f.id === b.farmerId)?.name}</Text>
              <Text style={{ marginTop: 4, color: "#6b7280" }}>QR Verified: {b.qrVerified ? "Yes" : "No"}</Text>
              <Text style={{ marginTop: 4, color: b.flagged ? "#b91c1c" : "#16a34a" }}>{b.flagged ? "Flagged (contradiction)" : `Status: ${b.status}`}</Text>
            </View>
          ))
        )}
      </View>

      {/* Scanner modal-like screen */}
      {scanning && (
        <View style={[styles.card, { marginTop: 12 }]}>
          <Text style={styles.bold}>Camera Scanner</Text>
          <Text style={{ marginTop: 8, color: "#6b7280" }}>Point camera at QR — scanner will auto-detect.</Text>

          <View style={{ marginTop: 12, height: 320, borderRadius: 12, overflow: "hidden", backgroundColor: "#000" }}>
            <BarCodeScanner
              onBarCodeScanned={scanning ? onBarCodeScanned : undefined}
              style={{ flex: 1 }}
            />
          </View>

          <View style={{ marginTop: 12, flexDirection: "row", justifyContent: "space-between" }}>
            <TouchableOpacity style={[styles.submitBtn, { flex: 1, marginRight: 8 }]} onPress={() => setScanning(false)}>
              <Text style={styles.submitTxt}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </ScrollView>
  );

  const renderPhotosTab = () => (
    <ScrollView style={styles.scroll}>
      <View style={styles.card}>
        <Text style={styles.safeTitle}>Rapid Test Photo Upload</Text>
        <Text style={styles.safeSub}>Upload the rapid test (strip) photo for suspicious batches. AI will validate the result.</Text>

        <Text style={{ marginTop: 12, color: "#6b7280" }}>Suspicious farmers (multi-cow with some in withdrawal):</Text>
        {farmers.filter(isSuspiciousFarmer).length === 0 ? (
          <Text style={{ marginTop: 8, color: "#6b7280" }}>No suspicious farmers right now.</Text>
        ) : (
          farmers.filter(isSuspiciousFarmer).map(f => {
            const farmerBatches = batches.filter(b => b.farmerId === f.id && b.status === "Pending");
            const batch = farmerBatches[0] ?? null;
            return (
              <View key={f.id} style={[styles.card, { marginTop: 12 }]}>
                <Text style={styles.bold}>{f.name}</Text>
                <Text style={{ color: "#6b7280", marginTop: 6 }}>Animals: {f.animals.map(a => a.name).join(", ")}</Text>
                <View style={{ flexDirection: "row", gap: 8, marginTop: 12 }}>
                  <TouchableOpacity style={[styles.submitBtn, { flex: 1 }]} onPress={() => {
                    // Create batch for farmer if none
                    if (!batch) {
                      const newBatch: BatchRecord = {
                        id: `B-${Date.now()}`,
                        farmerId: f.id,
                        type: "Milk",
                        qrVerified: !!f.badge,
                        status: "Pending",
                        timestamp: new Date().toISOString(),
                      };
                      setBatches(prev => [newBatch, ...prev]);
                      Alert.alert("New batch created", "Please pick/take photo to verify.");
                      return;
                    }
                    // otherwise pick photo for existing batch
                    pickImageAndVerify(batch.id);
                  }}>
                    <Text style={styles.submitTxt}>{batch ? "Upload Photo & Verify" : "Create Batch"}</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={[styles.secondaryButton, { flex: 1 }]} onPress={() => takePhotoAndVerify(batch ? batch.id : (() => {
                    Alert.alert("Create batch first", "Tap 'Create Batch' to create a batch before taking photo."); return "";
                  })())}>
                    <Text style={{ textAlign: "center", fontWeight: "700" }}>Take Photo</Text>
                  </TouchableOpacity>
                </View>

                {/* Show photo + AI result if exists */}
                {batch && batch.photoUri ? (
                  <View style={{ marginTop: 12 }}>
                    <Image source={{ uri: batch.photoUri }} style={{ width: "100%", height: 160, borderRadius: 8 }} />
                    <Text style={{ marginTop: 8, color: batch.aiSafe ? "#16a34a" : "#b91c1c" }}>
                      AI Result: {batch.aiSafe ? "Safe" : "Unsafe"} {batch.aiConfidence ? `(${batch.aiConfidence}%)` : ""}
                    </Text>
                  </View>
                ) : null}
              </View>
            );
          })
        )}
      </View>
    </ScrollView>
  );

  const renderDecisionTab = () => (
    <ScrollView style={styles.scroll}>
      <View style={styles.card}>
        <Text style={styles.safeTitle}>Accept / Reject Produce</Text>
        <Text style={styles.safeSub}>Review AI result and accept or reject manually.</Text>

        {batches.length === 0 ? <Text style={{ marginTop: 8, color: "#6b7280" }}>No batches yet.</Text> : (
          batches.map(b => (
            <View key={b.id} style={[styles.card, { marginTop: 12 }]}>
              <Text style={styles.bold}>Batch {b.id}</Text>
              <Text style={{ color: "#6b7280", marginTop: 6 }}>Farmer: {farmers.find(f => f.id === b.farmerId)?.name}</Text>
              <Text style={{ color: "#6b7280", marginTop: 4 }}>AI: {b.aiSafe == null ? "Pending" : (b.aiSafe ? `Safe (${b.aiConfidence}%)` : `Unsafe (${b.aiConfidence}%)`)}</Text>
              <View style={{ flexDirection: "row", marginTop: 10 }}>
                <TouchableOpacity style={[styles.submitBtn, { flex: 1, marginRight: 8 }]} onPress={() => acceptRejectBatch(b.id, "Accept")}>
                  <Text style={styles.submitTxt}>Accept</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.secondaryButton, { flex: 1 }]} onPress={() => acceptRejectBatch(b.id, "Reject")}>
                  <Text style={{ textAlign: "center", fontWeight: "700" }}>Reject</Text>
                </TouchableOpacity>
              </View>
              {b.photoUri ? <Image source={{ uri: b.photoUri }} style={{ width: "100%", height: 140, marginTop: 12, borderRadius: 8 }} /> : null}
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );

  const renderReportsTab = () => {
    const total = batches.length;
    const accepted = batches.filter(b => b.status === "Accepted").length;
    const rejected = batches.filter(b => b.status === "Rejected").length;
    const flagged = batches.filter(b => b.flagged).length;

    return (
      <ScrollView style={styles.scroll}>
        <View style={styles.card}>
          <Text style={styles.safeTitle}>Compliance Reports</Text>
          <Text style={styles.safeSub}>Summary of scanned batches & AI validations, sent to regulator.</Text>

          <View style={{ marginTop: 12 }}>
            <Text style={styles.bold}>Total batches: <Text style={styles.bold}>{total}</Text></Text>
            <Text style={{ marginTop: 4 }}>Accepted: {accepted}</Text>
            <Text style={{ marginTop: 2 }}>Rejected: {rejected}</Text>
            <Text style={{ marginTop: 2 }}>Flagged (contradictions): {flagged}</Text>
          </View>

          <TouchableOpacity style={styles.submitBtn} onPress={sendComplianceReport}>
            <Text style={styles.submitTxt}>Send to Regulator</Text>
          </TouchableOpacity>

          {/* Recent details */}
          <Text style={{ marginTop: 12, color: "#6b7280" }}>Recent details:</Text>
          {batches.map(b => (
            <View key={b.id} style={[styles.card, { marginTop: 12 }]}>
              <Text style={styles.bold}>Batch {b.id}</Text>
              <Text style={{ marginTop: 4, color: "#6b7280" }}>Farmer: {farmers.find(f => f.id === b.farmerId)?.name}</Text>
              <Text style={{ marginTop: 2, color: "#6b7280" }}>Status: {b.status}</Text>
              <Text style={{ marginTop: 2, color: "#6b7280" }}>AI: {b.aiSafe == null ? "Pending" : (b.aiSafe ? `Safe (${b.aiConfidence}%)` : `Unsafe (${b.aiConfidence}%)`)}</Text>
              <Text style={{ marginTop: 2, color: b.flagged ? "#b91c1c" : "#6b7280" }}>{b.flagged ? "Flagged for contradiction" : ""}</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    );
  };

  /***** Main render *****/
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => {/* navigate back */}}>
          <Text style={styles.backTxt}>←</Text>
        </TouchableOpacity>
        <Text style={styles.headerTxt}>Collection Center</Text>
        <View style={{ width: 36 }} />
      </View>

      {/* Tabs */}
      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", gap: 8 }}>
          {(["Scan", "Photos", "Decision", "Reports"] as const).map(tab => (
            <TouchableOpacity
              key={tab}
              style={[styles.card, { flex: 1, marginRight: tab !== "Reports" ? 8 : 0, backgroundColor: activeTab === tab ? "#E6F2F0" : "white" }]}
              onPress={() => setActiveTab(tab)}
            >
              <Text style={{ fontWeight: activeTab === tab ? "700" : "600", color: "#0A364F", textAlign: "center" }}>{tab}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Active content */}
      <View style={{ flex: 1, marginTop: 12 }}>
        {activeTab === "Scan" && renderScanTab()}
        {activeTab === "Photos" && renderPhotosTab()}
        {activeTab === "Decision" && renderDecisionTab()}
        {activeTab === "Reports" && renderReportsTab()}
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity style={styles.footerItem} onPress={() => setActiveTab("Scan")}>
          <MaterialIcons name="qr-code-scanner" size={20} color={activeTab === "Scan" ? "#0A364F" : "#9ca3af"} />
          <Text style={activeTab === "Scan" ? styles.activeLabel : styles.label}>Scan</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.footerItem} onPress={() => setActiveTab("Photos")}>
          <MaterialIcons name="photo-camera" size={20} color={activeTab === "Photos" ? "#0A364F" : "#9ca3af"} />
          <Text style={activeTab === "Photos" ? styles.activeLabel : styles.label}>Photos</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.footerItem} onPress={() => setActiveTab("Decision")}>
          <MaterialIcons name="check-circle" size={20} color={activeTab === "Decision" ? "#0A364F" : "#9ca3af"} />
          <Text style={activeTab === "Decision" ? styles.activeLabel : styles.label}>Decide</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.footerItem} onPress={() => setActiveTab("Reports")}>
          <MaterialIcons name="description" size={20} color={activeTab === "Reports" ? "#0A364F" : "#9ca3af"} />
          <Text style={activeTab === "Reports" ? styles.activeLabel : styles.label}>Reports</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/***** Styles (you provided; kept names and scheme) *****/
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backBtn: { padding: 8, borderRadius: 20, backgroundColor: "#f3f3f3" },
  backTxt: { fontSize: 18, color: "#0A364F" },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },

  scroll: { padding: 16, gap: 16 },
  card: { backgroundColor: "white", borderRadius: 16, padding: 20, shadowOpacity: 0.1, shadowRadius: 3 },
  label: { fontSize: 14, color: "#6b7280", fontWeight: "500" },
  input: {
    marginTop: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    fontSize: 16,
    color: "#0A364F",
  },

  safeTitle: { fontSize: 16, fontWeight: "600", color: "#0A364F" },
  safeSub: { fontSize: 14, marginTop: 4, color: "#6b7280" },
  bold: { fontWeight: "bold", color: "#0A364F" },

  progressOuter: { marginTop: 12, height: 8, borderRadius: 8, backgroundColor: "#e5e7eb" },
  progressInner: { height: "100%", backgroundColor: "#0A364F", borderRadius: 8 },

  submitBtn: {
    backgroundColor: "#0A364F",
    borderRadius: 9999,
    paddingVertical: 16,
    marginTop: 20,
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  submitTxt: { textAlign: "center", color: "white", fontWeight: "bold", fontSize: 16 },
  secondaryButton: {
    backgroundColor: "#E5E7EB", // light gray
    borderRadius: 9999,
    paddingVertical: 16,
    marginTop: 10,
  },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },
});
