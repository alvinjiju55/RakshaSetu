import React from "react";
import { View, Text, StyleSheet, ScrollView, Dimensions } from "react-native";
import { LineChart } from "react-native-chart-kit";

const screenWidth = Dimensions.get("window").width;

export default function RegulatorDashboard() {
  // 📊 Compliance Trend Data
  const lineData = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May"],
    datasets: [
      {
        data: [72, 85, 78, 90, 95],
        color: () => "#0A364F", // line color
        strokeWidth: 3,
      },
    ],
    legend: ["Compliance %"],
  };

  // 🌍 Heatmap-like Data (using multiple datasets as a workaround)
  // ChartKit doesn’t have native heatmaps → we fake it with grouped bar chart
  const heatmapData = {
    labels: ["North", "South", "East"],
    datasets: [
      { data: [85, 70, 60], color: () => "#4caf50" }, // Jan
      { data: [90, 80, 65], color: () => "#2196f3" }, // Feb
      { data: [95, 85, 75], color: () => "#ff9800" }, // Mar
    ],
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTxt}>Regulatory Dashboard</Text>
      </View>

      {/* Charts */}
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Line Chart */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Compliance Trends Over Time</Text>
          <LineChart
            data={lineData}
            width={screenWidth - 32}
            height={250}
            yAxisSuffix="%"
            chartConfig={{
              backgroundColor: "white",
              backgroundGradientFrom: "#E0F2E9",
              backgroundGradientTo: "#E0F2E9",
              decimalPlaces: 0,
              color: () => "#0A364F",
              labelColor: () => "#0A364F",
            }}
            bezier
            style={{ borderRadius: 16 }}
          />
        </View>

        {/* Fake Heatmap as Grouped Bar Chart */}
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Regional Compliance (Jan–Mar)</Text>
          <LineChart
            data={{
              labels: heatmapData.labels,
              datasets: heatmapData.datasets,
            }}
            width={screenWidth - 32}
            height={250}
            yAxisSuffix="%"
            chartConfig={{
              backgroundColor: "white",
              backgroundGradientFrom: "#E0F2E9",
              backgroundGradientTo: "#E0F2E9",
              decimalPlaces: 0,
              color: () => "#0A364F",
              labelColor: () => "#0A364F",
            }}
            style={{ borderRadius: 16 }}
          />
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  header: {
    padding: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 3,
    alignItems: "center",
  },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },
  scroll: { padding: 16, gap: 16 },
  card: {
    backgroundColor: "white",
    borderRadius: 16,
    padding: 12,
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
    color: "#0A364F",
    textAlign: "center",
  },
});