import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  TextInput,
  Platform,
  KeyboardAvoidingView,
  FlatList
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";

// Types
type Animal = {
  id: string;
  name: string;
  lastDrug: string;
  withdrawalDaysLeft: number;
};

type Message = {
  sender: "farmer" | "vet";
  text: string;
  time: string;
};

type Farmer = {
  id: string;
  name: string;
  animals: Animal[];
  messages: Message[];
};

// Dummy Data
const DUMMY_FARMERS: Farmer[] = [
  {
    id: "F001",
    name: "Farmer A",
    animals: [
      { id: "C001", name: "Cow #123", lastDrug: "Drug A", withdrawalDaysLeft: 2 },
      { id: "C002", name: "Cow #124", lastDrug: "Drug B", withdrawalDaysLeft: 0 }
    ],
    messages: [
      { sender: "farmer", text: "Cow #123 has mastitis", time: "10:30 AM" }
    ]
  },
  {
    id: "F002",
    name: "Farmer B",
    animals: [
      { id: "C003", name: "Cow #223", lastDrug: "Drug C", withdrawalDaysLeft: 3 }
    ],
    messages: []
  }
];

const AI_SUGGESTIONS = [
  "For persistent cases of mastitis, consider switching to combination therapy with Drug C."
];

export default function VetDashboard() {
  const [loading, setLoading] = useState(true);
  const tabs = ["Farmers", "Prescription", "Compliance", "Alerts", "Chat"] as const;
  type TabType = typeof tabs[number]; // "Farmers" | "Prescription" | "Compliance" | "Alerts" | "Chat"
  const [activeTab, setActiveTab] = useState<TabType>("Farmers");

  const [farmers, setFarmers] = useState<Farmer[]>(DUMMY_FARMERS);
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [complianceScore, setComplianceScore] = useState(85);

  // Chat states
  const [activeChat, setActiveChat] = useState<Farmer | null>(null);
  const [chatInput, setChatInput] = useState<string>("");

  // Prescription inputs
  const [drug, setDrug] = useState("");
  const [dosage, setDosage] = useState("");
  const [duration, setDuration] = useState("");
  const [withdrawal, setWithdrawal] = useState("");

  useEffect(() => {
    // Simulate API fetch
    const fetchData = async () => {
      // await fetch logic here
      setLoading(false);
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#0d8bf2" />
      </View>
    );
  }

  // Chat functions
  const openChat = (farmerId: string) => {
    const convo = farmers.find(f => f.id === farmerId);
    if (convo) setActiveChat(convo);
  };

  const sendMessage = () => {
    if (!chatInput.trim() || !activeChat) return;
    const newMessage: Message = {
      sender: "vet",
      text: chatInput,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    };
    const updatedConvo = { ...activeChat, messages: [...activeChat.messages, newMessage] };
    setFarmers(farmers.map(f => f.id === activeChat.id ? updatedConvo : f));
    setActiveChat(updatedConvo);
    setChatInput("");
  };

  const renderMessageItem = ({ item }: { item: Message }) => (
    <View style={{
      padding: 12,
      borderRadius: 12,
      marginVertical: 4,
      maxWidth: "75%",
      alignSelf: item.sender === "farmer" ? "flex-start" : "flex-end",
      backgroundColor: item.sender === "farmer" ? "#16a34a" : "#0d8bf2"
    }}>
      <Text style={{ color: "#fff" }}>{item.text}</Text>
      <Text style={{ fontSize: 10, color: "#e5e7eb", marginTop: 4 }}>{item.time}</Text>
    </View>
  );

  // Tabs
  const renderFarmersTab = () => (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      {farmers.map(farmer => (
        <View key={farmer.id} style={{ marginBottom: 16 }}>
          <Text style={{ fontWeight: "700", fontSize: 16 }}>{farmer.name}</Text>
          {farmer.animals.map(animal => (
            <TouchableOpacity
              key={animal.id}
              style={[styles.card, { marginTop: 8, backgroundColor: selectedAnimal?.id === animal.id ? "#e0f2fe" : "#fff" }]}
              onPress={() => setSelectedAnimal(animal)}
            >
              <Text style={{ fontWeight: "600" }}>{animal.name}</Text>
              <Text style={{ fontSize: 12, color: "#6b7280" }}>
                Last Drug: {animal.lastDrug} | Withdrawal: {animal.withdrawalDaysLeft} days left
              </Text>
            </TouchableOpacity>
          ))}
          <TouchableOpacity
            style={{ marginTop: 8, flexDirection: "row", alignItems: "center" }}
            onPress={() => openChat(farmer.id)}
          >
            <MaterialIcons name="chat" size={24} color="#0d8bf2" />
            <Text style={{ marginLeft: 8, color: "#0d8bf2", fontWeight: "600" }}>Open Chat</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );

  const renderEPrescriptionTab = () => (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      {selectedAnimal ? (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Prescription for {selectedAnimal.name}</Text>
          <View style={{ marginTop: 12 }}>
            <Text>Drug:</Text>
            <TouchableOpacity style={styles.selectBox}><Text>{drug || "Select Drug"}</Text></TouchableOpacity>
            <Text style={{ marginTop: 8 }}>Dosage:</Text>
            <TouchableOpacity style={styles.selectBox}><Text>{dosage || "Select Dosage"}</Text></TouchableOpacity>
            <Text style={{ marginTop: 8 }}>Duration:</Text>
            <TouchableOpacity style={styles.selectBox}><Text>{duration || "Select Duration"}</Text></TouchableOpacity>
            <Text style={{ marginTop: 8 }}>Withdrawal:</Text>
            <TouchableOpacity style={styles.selectBox}><Text>{withdrawal || "Select Withdrawal"}</Text></TouchableOpacity>

            <View style={styles.aiBox}>
              <MaterialIcons name="auto-awesome" size={24} color="#0d8bf2" />
              <Text style={{ marginLeft: 8 }}>{AI_SUGGESTIONS[0]}</Text>
            </View>

            <TouchableOpacity style={styles.primaryButton}><Text style={{ color: "#fff", fontWeight: "700" }}>Issue Prescription</Text></TouchableOpacity>
            <TouchableOpacity style={styles.secondaryButton}><Text style={{ fontWeight: "700" }}>Save as Draft</Text></TouchableOpacity>
          </View>
        </View>
      ) : (
        <Text>Select an animal from Farmers tab to issue prescription.</Text>
      )}
    </ScrollView>
  );

  const renderComplianceTab = () => (
    <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Compliance Score</Text>
        <Text style={{ fontSize: 32, fontWeight: "700", marginTop: 8 }}>{complianceScore}%</Text>
        <Text style={{ fontSize: 12, color: "#16a34a", marginTop: 4 }}>Based on treatment logs</Text>
      </View>
    </ScrollView>
  );

  const renderAlertsTab = () => (
  <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 100 }}>
    {farmers.map(farmer =>
      farmer.animals.map(animal => (
        <View
          key={animal.id}
          style={[
            styles.card,
            {
              borderLeftWidth: 4,
              borderLeftColor: animal.withdrawalDaysLeft <= 1 ? "#dc2626" : "#f59e0b",
              marginBottom: 8
            }
          ]}
        >
          <Text style={{ fontWeight: "700", fontSize: 16 }}>
            {animal.name} ({farmer.name})
          </Text>
          <Text style={{ fontSize: 12, color: "#6b7280", marginVertical: 4 }}>
            Last Drug: {animal.lastDrug}
          </Text>
          <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
            <Text style={{ fontSize: 12, color: animal.withdrawalDaysLeft <= 1 ? "#b91c1c" : "#f59e0b" }}>
              Withdrawal: {animal.withdrawalDaysLeft} days left
            </Text>
            <TouchableOpacity
              style={{
                backgroundColor: "#0d8bf2",
                paddingVertical: 6,
                paddingHorizontal: 12,
                borderRadius: 8,
                shadowColor: "#000",
                shadowOpacity: 0.1,
                shadowOffset: { width: 0, height: 2 },
                shadowRadius: 4
              }}
              onPress={() => alert(`Dosage log for ${animal.name} validated!`)}
            >
              <Text style={{ color: "#fff", fontWeight: "700", fontSize: 12 }}>Validate</Text>
            </TouchableOpacity>
          </View>
        </View>
      ))
    )}
  </ScrollView>
);


  const renderChatTab = () =>
    activeChat ? (
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={90}>
        <View style={{ flexDirection: "row", justifyContent: "space-between", padding: 12, borderBottomWidth: 1, borderColor: "#e5e7eb" }}>
          <TouchableOpacity onPress={() => setActiveChat(null)}>
            <Text style={{ color: "#0d8bf2" }}>{"< Back"}</Text>
          </TouchableOpacity>
          <Text style={{ fontWeight: "700", fontSize: 16 }}>{activeChat.name}</Text>
          <View style={{ width: 40 }} />
        </View>

        <ScrollView horizontal style={{ padding: 8 }} showsHorizontalScrollIndicator={false}>
          {activeChat.animals.map(animal => (
            <TouchableOpacity
              key={animal.id}
              style={{ padding: 8, borderWidth: 1, borderColor: selectedAnimal?.id === animal.id ? "#0d8bf2" : "#d1d5db", borderRadius: 8, marginRight: 8 }}
              onPress={() => setSelectedAnimal(animal)}
            >
              <Text>{animal.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <FlatList
          data={activeChat.messages}
          keyExtractor={(_, idx) => idx.toString()}
          renderItem={renderMessageItem}
          contentContainerStyle={{ padding: 16 }}
        />

        <View style={{ flexDirection: "row", padding: 12, borderTopWidth: 1, borderColor: "#e5e7eb" }}>
          <TextInput
            style={{ flex: 1, borderWidth: 1, borderColor: "#d1d5db", borderRadius: 12, paddingHorizontal: 12 }}
            placeholder="Type your message..."
            value={chatInput}
            onChangeText={setChatInput}
          />
          <TouchableOpacity style={{ backgroundColor: "#0d8bf2", padding: 12, borderRadius: 12, marginLeft: 8 }} onPress={sendMessage}>
            <MaterialIcons name="send" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    ) : (
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        {farmers.map(farmer => (
          <TouchableOpacity key={farmer.id} style={styles.card} onPress={() => openChat(farmer.id)}>
            <Text style={{ fontWeight: "700", fontSize: 16 }}>{farmer.name}</Text>
            <Text style={{ fontSize: 12, color: "#6b7280", marginTop: 4 }}>
              {(farmer.messages[farmer.messages.length - 1]?.text) || "No messages yet"}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    );

  const renderActiveTab = () => {
    switch (activeTab) {
      case "Farmers": return renderFarmersTab();
      case "Prescription": return renderEPrescriptionTab();
      case "Compliance": return renderComplianceTab();
      case "Alerts": return renderAlertsTab();
      case "Chat": return renderChatTab();
      default: return renderFarmersTab();
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: "#fefcf8" }}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Veterinarian Dashboard</Text>
      </View>

      {/* Tabs */}
      <View style={styles.tabsContainer}>
        {["Farmers", "Prescription", "Compliance", "Alerts", "Chat"].map(tab => (
          <TouchableOpacity key={tab} onPress={() => setActiveTab(tab as TabType)}>
            <Text style={activeTab === tab ? styles.activeTabText : styles.tabText}>{tab}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {renderActiveTab()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },

  header: {
    padding: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 3,
    alignItems: "center",
  },
  headerTitle: { fontWeight: "bold", fontSize: 18, color: "#0A364F" },

  tabsContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    marginVertical: 8,
    backgroundColor: "white",
    paddingVertical: 6,
    borderRadius: 12,
    marginHorizontal: 12,
    shadowOpacity: 0.05,
    shadowRadius: 3,
  },
  tabText: { color: "#6b7280", fontWeight: "600" },
  activeTabText: { color: "#0A364F", fontWeight: "700" },

  card: {
    backgroundColor: "white",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  cardTitle: { fontWeight: "700", fontSize: 16, color: "#0A364F" },

  selectBox: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    padding: 10,
    marginTop: 4,
  },

  aiBox: {
    flexDirection: "row",
    marginTop: 12,
    padding: 10,
    borderWidth: 1,
    borderColor: "#0A364F",
    borderRadius: 8,
    backgroundColor: "#E0F2E9",
    alignItems: "center",
  },

  primaryButton: {
    marginTop: 12,
    backgroundColor: "#0A364F",
    padding: 14,
    borderRadius: 9999,
    alignItems: "center",
  },
  secondaryButton: {
    marginTop: 8,
    backgroundColor: "#e5e7eb",
    padding: 14,
    borderRadius: 9999,
    alignItems: "center",
  },

  // Chat bubbles (to match scheme)
  farmerBubble: {
    backgroundColor: "#16a34a",
    padding: 12,
    borderRadius: 12,
    marginVertical: 4,
    maxWidth: "75%",
    alignSelf: "flex-start",
  },
  vetBubble: {
    backgroundColor: "#0A364F",
    padding: 12,
    borderRadius: 12,
    marginVertical: 4,
    maxWidth: "75%",
    alignSelf: "flex-end",
  },
  bubbleText: { color: "white" },
  bubbleTime: { fontSize: 10, color: "#e5e7eb", marginTop: 4 },
});

