import React, { useState, useEffect } from "react";
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet, KeyboardAvoidingView } from "react-native";

export default function VetChat() {
  const [messages, setMessages] = useState<{sender: "farmer" | "vet"; text: string}[]>([]);
  const [input, setInput] = useState("");

  const sendMessage = () => {
    if (input.trim() === "") return;
    setMessages([...messages, { sender: "farmer", text: input }]);
    setInput("");
    // Here you can call API to send message to backend and vet
  };

  // TODO: Fetch messages from backend using useEffect

  const renderItem = ({ item }: { item: { sender: string; text: string } }) => (
    <View style={[styles.messageBubble, item.sender === "farmer" ? styles.farmerBubble : styles.vetBubble]}>
      <Text style={{ color: item.sender === "farmer" ? "#fff" : "#111827" }}>{item.text}</Text>
    </View>
  );

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior="padding">
      <FlatList
        data={messages}
        keyExtractor={(_, index) => index.toString()}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 16 }}
      />
      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Type your message..."
          value={input}
          onChangeText={setInput}
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
          <Text style={{ color: "#fff", fontWeight: "700" }}>Send</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  messageBubble: {
    padding: 12,
    borderRadius: 12,
    marginVertical: 4,
    maxWidth: "75%",
  },
  farmerBubble: {
    backgroundColor: "#16a34a",
    alignSelf: "flex-end",
  },
  vetBubble: {
    backgroundColor: "#f3f4f6",
    alignSelf: "flex-start",
  },
  inputContainer: {
    flexDirection: "row",
    padding: 8,
    borderTopWidth: 1,
    borderColor: "#d1d5db",
    backgroundColor: "#fff",
  },
  input: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#f3f4f6",
    borderRadius: 12,
    marginRight: 8,
  },
  sendButton: {
    backgroundColor: "#16a34a",
    borderRadius: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
  },
});
