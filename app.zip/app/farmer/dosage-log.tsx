import { useState } from "react";
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet, Alert } from "react-native";
import { Link } from "expo-router";

export default function DosageLog() {
  const [animalId, setAnimalId] = useState("");
  const [medicine, setMedicine] = useState("");
  const [date, setDate] = useState("");
  const [dosage, setDosage] = useState("");
  const [withdrawalDays, setWithdrawalDays] = useState<number | null>(null);

  const handleSave = async () => {
    if (!animalId || !medicine || !date || !dosage) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }

    // Simple withdrawal calculation logic (example: 1 day per 10 units dosage)
    const calculatedWithdrawal = Math.ceil(Number(dosage) / 10);
    setWithdrawalDays(calculatedWithdrawal);

    try {
      const response = await fetch("https://your-backend.com/api/dosage-log", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          animal_id: animalId,
          medicine_name: medicine,
          date,
          dosage: Number(dosage),
          withdrawal_days: calculatedWithdrawal,
        }),
      });

      if (response.ok) {
        Alert.alert("Success", "The dosage log is saved");
        // Reset inputs
        setAnimalId("");
        setMedicine("");
        setDate("");
        setDosage("");
      } else {
        Alert.alert("Error", "Failed to save log");
      }
    } catch (err) {
      Alert.alert("Error", "Something went wrong");
      console.error(err);
    }
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Link href="/farmer" asChild>
          <Pressable style={styles.backBtn}>
            <Text style={styles.backTxt}>←</Text>
          </Pressable>
        </Link>
        <Text style={styles.headerTxt}>Log Medicine</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Body */}
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Animal ID */}
        <View style={styles.card}>
          <Text style={styles.label}>Animal ID</Text>
          <TextInput
            placeholder="Enter Animal ID"
            style={styles.input}
            value={animalId}
            onChangeText={setAnimalId}
          />
        </View>

        {/* Medicine Name */}
        <View style={styles.card}>
          <Text style={styles.label}>Medicine Name</Text>
          <TextInput
            placeholder="Enter medicine name"
            style={styles.input}
            value={medicine}
            onChangeText={setMedicine}
          />
        </View>

        {/* Date */}
        <View style={styles.card}>
          <Text style={styles.label}>Date</Text>
          <TextInput
            placeholder="YYYY-MM-DD"
            style={styles.input}
            value={date}
            onChangeText={setDate}
          />
        </View>

        {/* Dosage */}
        <View style={styles.card}>
          <Text style={styles.label}>Dosage (units)</Text>
          <TextInput
            placeholder="Enter dosage"
            style={styles.input}
            keyboardType="numeric"
            value={dosage}
            onChangeText={setDosage}
          />
        </View>

        {/* Withdrawal Days */}
        {withdrawalDays !== null && (
          <View style={styles.card}>
            <Text style={styles.safeTitle}>Days until milk is safe</Text>
            <Text style={styles.safeSub}>
              Withdrawal days: <Text style={styles.bold}>{withdrawalDays}</Text>
            </Text>

            <View style={styles.progressOuter}>
              <View
                style={[styles.progressInner, { width: `${Math.min(withdrawalDays * 10, 100)}%` }]}
              />
            </View>
          </View>
        )}

        {/* Submit Button */}
        <Pressable style={styles.submitBtn} onPress={handleSave}>
          <Text style={styles.submitTxt}>Log Medicine</Text>
        </Pressable>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Link href="/farmer" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.activeIcon}>🏠</Text>
            <Text style={styles.activeLabel}>Home</Text>
          </Pressable>
        </Link>

        <Link href="/farmer/dosage-log" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.activeIcon}>📋</Text>
            <Text style={styles.activeLabel}>Log</Text>
          </Pressable>
        </Link>

        <Link href="/farmer/alerts" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.icon}>🔔</Text>
            <Text style={styles.label}>Alerts</Text>
          </Pressable>
        </Link>

        <Link href="/farmer/profile" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.icon}>👤</Text>
            <Text style={styles.label}>Profile</Text>
          </Pressable>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 16,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  backBtn: { padding: 8, borderRadius: 20, backgroundColor: "#f3f3f3" },
  backTxt: { fontSize: 18, color: "#0A364F" },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },

  scroll: { padding: 16, gap: 16 },
  card: { backgroundColor: "white", borderRadius: 16, padding: 20, shadowOpacity: 0.1, shadowRadius: 3 },
  label: { fontSize: 14, color: "#6b7280", fontWeight: "500" },
  input: {
    marginTop: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    fontSize: 16,
    color: "#0A364F",
  },

  safeTitle: { fontSize: 16, fontWeight: "600", color: "#0A364F" },
  safeSub: { fontSize: 14, marginTop: 4, color: "#6b7280" },
  bold: { fontWeight: "bold", color: "#0A364F" },

  progressOuter: { marginTop: 12, height: 8, borderRadius: 8, backgroundColor: "#e5e7eb" },
  progressInner: { height: "100%", backgroundColor: "#0A364F", borderRadius: 8 },

  submitBtn: {
    backgroundColor: "#0A364F",
    borderRadius: 9999,
    paddingVertical: 16,
    marginTop: 20,
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  submitTxt: { textAlign: "center", color: "white", fontWeight: "bold", fontSize: 16 },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },
});
