import React, { useState, useEffect } from "react";
import {
  View,
  Text,
  TextInput,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { MaterialIcons } from "@expo/vector-icons";

export default function Chatbot() {
  const [messages, setMessages] = useState<{ sender: "farmer" | "ai"; text: string }[]>([]);
  const [input, setInput] = useState("");

  // Send user message
  const sendMessage = async () => {
    if (input.trim() === "") return;

    // Add farmer message to chat
    setMessages((prev) => [...prev, { sender: "farmer", text: input }]);
    const userMessage = input;
    setInput("");

    // TODO: Call your AI backend / API
    // Simulate AI response for now
    setTimeout(() => {
      const aiResponse = `AI Suggestion for: "${userMessage}"`; // Replace with API result
      setMessages((prev) => [...prev, { sender: "ai", text: aiResponse }]);
    }, 800);
  };

  const renderItem = ({ item }: { item: { sender: string; text: string } }) => (
    <View style={[styles.messageBubble, item.sender === "farmer" ? styles.farmerBubble : styles.aiBubble]}>
      <Text style={[styles.messageText, item.sender === "farmer" ? { color: "#fff" } : { color: "#111827" }]}>
        {item.text}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>AI Assistant</Text>
      </View>

      {/* Chat */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={90}
      >
        <FlatList
          data={messages}
          keyExtractor={(_, index) => index.toString()}
          renderItem={renderItem}
          contentContainerStyle={{ padding: 16 }}
        />

        {/* Input */}
        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="Ask AI..."
            value={input}
            onChangeText={setInput}
          />
          <TouchableOpacity style={styles.sendButton} onPress={sendMessage}>
            <MaterialIcons name="send" size={24} color="#fff" />
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fefcf8" },
  header: {
    padding: 12,
    borderBottomWidth: 1,
    borderColor: "#d1d5db",
    backgroundColor: "#fefcf8",
  },
  headerTitle: { fontWeight: "700", fontSize: 16, color: "#111827" },
  messageBubble: {
    padding: 12,
    borderRadius: 12,
    marginVertical: 4,
    maxWidth: "75%",
  },
  farmerBubble: { backgroundColor: "#16a34a", alignSelf: "flex-end" },
  aiBubble: { backgroundColor: "#f3f4f6", alignSelf: "flex-start" },
  messageText: { fontSize: 14 },
  inputContainer: {
    flexDirection: "row",
    padding: 8,
    borderTopWidth: 1,
    borderColor: "#d1d5db",
    backgroundColor: "#fefcf8",
  },
  input: {
    flex: 1,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: "#f3f4f6",
    borderRadius: 12,
    marginRight: 8,
    fontSize: 14,
    color: "#111827",
  },
  sendButton: {
    backgroundColor: "#16a34a",
    borderRadius: 12,
    paddingHorizontal: 16,
    justifyContent: "center",
    alignItems: "center",
  },
});
