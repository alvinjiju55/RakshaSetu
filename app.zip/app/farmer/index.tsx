import React, { useEffect, useState } from "react";
import { View, Text, ScrollView, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from "react-native";
import { Link } from "expo-router";
import { MaterialIcons } from "@expo/vector-icons";

export default function FarmerDashboard() {
  const [farmerName, setFarmerName] = useState("");
  const [withdrawalAlerts, setWithdrawalAlerts] = useState<{animal_id: string; days_left: number;}[]>([]);
  const [rewardProgress, setRewardProgress] = useState<{completedLogs: number; requiredLogs: number}>({completedLogs: 0, requiredLogs: 5});
  const [loading, setLoading] = useState(true);

  const quickActions = [
    {
      title: "Log Drug Use",
      description: "Record medication details",
      href: "/farmer/dosage-log",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuB1idt9yxR1Kg4DTs5w7B_KIllTLkS7ej8ALHUrcuuHEc_AxgpeY5hWiodytJS38_-9kXQRXI-oWXj06XMlptp69f-M3XkNvV3RqLYertNeZTqxh27bQdl6xANZadXctKY5HBx_SFhB3OZ9wLb3A1q3ui9Ry9V8w0rwXuN1za8YSGT43RCuj8shDmbcUQZEzhmPRosYM0kC-dK-oTwesQ7dEWs_Oi8IJMcQGtxg0fATV2N1bhEqWNOOBMStn80lzuCCK_Ywtgo-Fw",
    },
    {
      title: "Livestock Details",
      description: "Handle animal info",
      href: "/farmer/animal-info",
      image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAnNTpVo90nqL65mqYiunagssr_cqFIgbjWD0SFDhupqe6BMi0nFJ_KWX-BpaQPgIbIrxZ7GGthIyJDEoKTFa8hCNdwZH-Ao9wUm2WLc3RRlaMQr1rkmkxEQjR4eBcYtyYTTGWXvbW5gJPA7ZGCTuOhz03AAoRtTem1tT2bE26nENw7UwRu42X0MIrYXB1TkFjScxQVqM7Y5GMjTlmYHnd_fteGZS1tenMyBGast4LwxA3Cckki9Hli7uTPG-citRT3Ldm4mSXs9Q",
    },
  ];

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const farmerRes = await fetch("https://your-backend.com/api/farmer/me");
        const farmerData = await farmerRes.json();
        setFarmerName(farmerData.name);

        const alertsRes = await fetch("https://your-backend.com/api/farmer/withdrawal-alerts");
        const alertsData = await alertsRes.json();
        setWithdrawalAlerts(alertsData);

        const rewardsRes = await fetch("https://your-backend.com/api/farmer/rewards");
        const rewardsData = await rewardsRes.json();
        setRewardProgress(rewardsData);
      } catch (err) {
        console.error("Error fetching dashboard data:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, []);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator size="large" color="#16a34a" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <Image style={styles.profileImage} source={{ uri: "https://lh3.googleusercontent.com/aida-public/AB6AXuDSPSA-NnCqmocM-24_eheBlNUMV_YZD6qz07GgDTbMxGg45hLqZ890XhOxl9druFcdgo9hs1MNX82iPxQrE0xbP2sVFhHwM4sVF4M9EJoUycK0aEuO2UBr9LalOzZxkQc7K8ScsMzNdVi8JxHqkZQBRsRISawXq2c..." }} />
          <Text style={styles.headerTitle}>{farmerName}'s Livestock</Text>
        </View>

      <Link href="/farmer/qr-badge" asChild>
      <TouchableOpacity style={styles.qrButton}>
        <MaterialIcons name="qr-code" size={20} color="#374151" />
        <Text style={styles.qrText}>My QR Badge</Text>
    </TouchableOpacity>
  </Link>
</View>

      {/* Main content */}
      <ScrollView style={styles.main} contentContainerStyle={{ paddingBottom: 100 }}>
        {/* Quick Actions */}
        <Text style={styles.sectionTitle}>Quick Actions</Text>
        <View style={styles.quickActions}>
          {quickActions.map((action) => (
            <Link key={action.title} href={action.href} asChild>
              <TouchableOpacity style={styles.card}>
                <Image source={{ uri: action.image }} style={styles.cardImage} />
                <View style={styles.cardText}>
                  <Text style={styles.cardTitle}>{action.title}</Text>
                  <Text style={styles.cardDesc}>{action.description}</Text>
                </View>
              </TouchableOpacity>
            </Link>
          ))}
        </View>

        {/* Withdrawal Alerts */}
        <Text style={styles.sectionTitle}>Withdrawal Alerts</Text>
        {withdrawalAlerts.length === 0 ? (
          <Text style={{ color: "#6b7280", fontSize: 12 }}>No active withdrawal periods</Text>
        ) : (
          withdrawalAlerts.map((alert, idx) => (
            <View key={idx} style={[styles.card, { backgroundColor: "#fed7aa" }]}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                <View>
                  <Text style={{ fontWeight: "700", color: "#c2410c" }}>Animal ID: {alert.animal_id}</Text>
                  <Text style={{ fontSize: 12, color: "#c2410c" }}>Days left: {alert.days_left}</Text>
                </View>
                <Text style={{ fontSize: 24, fontWeight: "700", color: "#ea580c" }}>{alert.days_left}d</Text>
              </View>
            </View>
          ))
        )}

        {/* Rewards */}
        <Text style={styles.sectionTitle}>Rewards & Incentives</Text>
        <View style={{ height: 10, backgroundColor: "#e5e7eb", borderRadius: 5, marginBottom: 4 }}>
          <View style={{ width: `${(rewardProgress.completedLogs / rewardProgress.requiredLogs) * 100}%`, height: 10, backgroundColor: "#16a34a", borderRadius: 5 }} />
        </View>
        <Text style={{ fontSize: 12, color: "#6b7280", textAlign: "center" }}>
          Complete {rewardProgress.requiredLogs - rewardProgress.completedLogs} more logs to unlock rewards
        </Text>
      </ScrollView>

      {/* Chatbot */}
      <Link href="/farmer/chatbot" asChild>
        <TouchableOpacity style={styles.chatbotButton}>
          <MaterialIcons name="chat" size={24} color="#fff" />
        </TouchableOpacity>
      </Link>
      {/* Floating Vet Chat Button */}
      <Link href="/farmer/vet-chat" asChild>
        <TouchableOpacity style={styles.vetChatButton}>
          <MaterialIcons name="local-hospital" size={24} color="#fff" />
        </TouchableOpacity>
      </Link>
      


      {/* Footer */}
      <View style={styles.footer}>
        <Link href="/farmer" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>🏠</Text>
            <Text style={styles.activeLabel}>Home</Text>
          </View>
        </Link>

        <Link href="/farmer/dosage-log" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>📋</Text>
            <Text style={styles.label}>Log</Text>
          </View>
        </Link>

        <Link href="/farmer/alerts" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>🔔</Text>
            <Text style={styles.label}>Alerts</Text>
          </View>
        </Link>

        <Link href="/farmer/profile" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>👤</Text>
            <Text style={styles.activeLabel}>Profile</Text>
          </View>
        </Link>
      </View>
    </View>
    

  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fefcf8" },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 12,
    backgroundColor: "#fefcf8",
  },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 8 },
  profileImage: { width: 40, height: 40, borderRadius: 20 },
  headerTitle: { fontWeight: "700", fontSize: 18 },
  qrButton: { flexDirection: "row", alignItems: "center", padding: 6, borderRadius: 8 },
  qrText: { fontSize: 12, marginLeft: 4, color: "#374151" },
  main: { flex: 1, paddingHorizontal: 16, paddingTop: 8 },
  sectionTitle: { fontWeight: "700", fontSize: 16, color: "#111827", marginBottom: 8 },
  quickActions: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 16 },
  card: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#fff",
    padding: 12,
    borderRadius: 12,
    marginBottom: 8,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    width: "100%",
  },
  cardImage: { width: 64, height: 64, borderRadius: 8 },
  cardText: { flex: 1, marginLeft: 12 },
  cardTitle: { fontWeight: "700", fontSize: 14, color: "#111827" },
  cardDesc: { fontSize: 12, color: "#15803d" },
  chatbotButton: {
    position: "absolute",
    bottom: 100,
    right: 16,
    backgroundColor: "#16a34a",
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },
  vetChatButton: {
    position: "absolute",
    bottom: 170, // place it above the chatbot button
    right: 16,
    backgroundColor: "#2563eb", // blue for vet chat
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
  },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },
});
