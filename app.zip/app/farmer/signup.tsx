import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
} from "react-native";
import { Link, useRouter } from "expo-router";

export default function FarmerSignup() {
  const router = useRouter();

  const [name, setName] = useState("");
  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [state, setState] = useState("");

  const handleSignup = async () => {
    // 1. Validation
    if (!name || !emailOrPhone || !password || !confirmPassword || !city || !pincode || !state) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert("Error", "Passwords do not match");
      return;
    }

    // 2. Call backend API (example with fetch)
    try {
      const response = await fetch("https://your-backend.com/api/farmer/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, emailOrPhone, password, city, pincode, state }),
      });
      const data = await response.json();

      if (response.ok) {
        Alert.alert("Success", "Farmer registered successfully!");
        router.push("/farmer"); // Navigate to dashboard
      } else {
        Alert.alert("Error", data.message || "Signup failed");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Network error. Please try again.");
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.card}>
          <Text style={styles.title}>Farmer Sign Up</Text>

          <TextInput style={styles.input} placeholder="Full Name" value={name} onChangeText={setName} />
          <TextInput
            style={styles.input}
            placeholder="Email or Phone Number"
            value={emailOrPhone}
            onChangeText={setEmailOrPhone}
            keyboardType="email-address"
            autoCapitalize="none"
          />
          <TextInput style={styles.input} placeholder="Password" value={password} onChangeText={setPassword} secureTextEntry />
          <TextInput
            style={styles.input}
            placeholder="Confirm Password"
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            secureTextEntry
          />
          <TextInput style={styles.input} placeholder="City / Village" value={city} onChangeText={setCity} />
          <TextInput style={styles.input} placeholder="Pincode" value={pincode} onChangeText={setPincode} keyboardType="number-pad" />
          <TextInput style={styles.input} placeholder="State" value={state} onChangeText={setState} />

          <TouchableOpacity style={styles.button} onPress={handleSignup}>
            <Text style={styles.buttonText}>Sign Up</Text>
          </TouchableOpacity>

          <Text style={styles.orText}>Already registered?</Text>
          <Link href="/farmer/login" asChild>
            <TouchableOpacity style={{ ...styles.button, ...styles.loginButton }}>
              <Text style={{ ...styles.buttonText, color: "#16a34a" }}>Log In</Text>
            </TouchableOpacity>
          </Link>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f8fcf8" },
  scrollContainer: { flexGrow: 1, justifyContent: "center", alignItems: "center", padding: 16 },
  card: {
    width: "100%",
    maxWidth: 400,
    backgroundColor: "#ffffff",
    padding: 24,
    borderRadius: 16,
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 5,
  },
  title: { fontSize: 24, fontWeight: "700", marginBottom: 24, color: "#111827", textAlign: "center" },
  input: { width: "100%", backgroundColor: "#f3f4f6", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 16, fontSize: 16, color: "#111827" },
  button: { backgroundColor: "#16a34a", borderRadius: 12, paddingVertical: 12, alignItems: "center", marginBottom: 12, width: "100%" },
  loginButton: { backgroundColor: "#fefcf8", borderWidth: 1, borderColor: "#16a34a" },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  orText: { textAlign: "center", marginVertical: 8, color: "#6b7280", fontSize: 14 },
});
