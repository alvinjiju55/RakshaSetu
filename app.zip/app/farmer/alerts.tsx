import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, StyleSheet, ActivityIndicator, TouchableOpacity, Linking } from "react-native";
import { Link } from "expo-router";

export default function Alerts() {
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [vetAlerts, setVetAlerts] = useState<any[]>([]);
  const [eprescriptions, setEprescriptions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const res1 = await fetch("https://your-backend.com/api/farmer/withdrawals");
        setWithdrawals(await res1.json());

        const res2 = await fetch("https://your-backend.com/api/farmer/vet-alerts");
        setVetAlerts(await res2.json());

        const res3 = await fetch("https://your-backend.com/api/farmer/e-prescriptions");
        setEprescriptions(await res3.json());
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchAlerts();
  }, []);

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#0A364F" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        {/* Withdrawal Periods */}
        <Text style={styles.headerTxt}>Withdrawal Periods</Text>
        {withdrawals.length === 0 ? (
          <Text style={styles.noDataText}>No active withdrawal periods</Text>
        ) : (
          withdrawals.map((w, idx) => (
            <View key={idx} style={[styles.card, { backgroundColor: "#fee2e2" }]}>
              <Text style={styles.cardTitle}>{w.animal_id} - {w.medicine_name}</Text>
              <Text style={styles.cardText}>Safe Date: {w.safe_date}</Text>
              <Text style={styles.cardText}>Days Remaining: {w.days_remaining}</Text>
            </View>
          ))
        )}

        {/* Vet Alerts */}
        <Text style={[styles.headerTxt, { marginTop: 20 }]}>Vet Alerts</Text>
        {vetAlerts.length === 0 ? (
          <Text style={styles.noDataText}>No new vet alerts</Text>
        ) : (
          vetAlerts.map((v, idx) => (
            <View key={idx} style={[styles.card, { backgroundColor: "#dcfce7" }]}>
              <Text style={styles.cardTitle}>{v.title}</Text>
              <Text style={styles.cardText}>{v.message}</Text>
              <Text style={[styles.cardText, { fontSize: 12, color: "#6b7280" }]}>{v.date}</Text>
            </View>
          ))
        )}

        {/* E-Prescriptions */}
        <Text style={[styles.headerTxt, { marginTop: 20 }]}>E-Prescriptions</Text>
        {eprescriptions.length === 0 ? (
          <Text style={styles.noDataText}>No prescriptions yet</Text>
        ) : (
          eprescriptions.map((p, idx) => (
            <View key={idx} style={[styles.card, { backgroundColor: "#f0f9ff" }]}>
              <Text style={styles.cardTitle}>{p.medicine_name}</Text>
              <Text style={styles.cardText}>Dosage: {p.dosage}</Text>
              <Text style={styles.cardText}>Instructions: {p.instructions}</Text>
              <Text style={[styles.cardText, { fontSize: 12, color: "#6b7280" }]}>{p.date}</Text>
              {p.file_url && (
                <TouchableOpacity onPress={() => Linking.openURL(p.file_url)}>
                  <Text style={[styles.cardText, { color: "#0A364F", fontWeight: "600", marginTop: 4 }]}>
                    View Prescription
                  </Text>
                </TouchableOpacity>
              )}
            </View>
          ))
        )}
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Link href="/farmer" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>🏠</Text>
            <Text style={styles.activeLabel}>Home</Text>
          </View>
        </Link>
        <Link href="/farmer/dosage-log" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>📋</Text>
            <Text style={styles.label}>Log</Text>
          </View>
        </Link>
        <Link href="/farmer/alerts" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.activeIcon}>🔔</Text>
            <Text style={styles.activeLabel}>Alerts</Text>
          </View>
        </Link>
        <Link href="/farmer/profile" asChild>
          <View style={styles.footerItem}>
            <Text style={styles.icon}>👤</Text>
            <Text style={styles.label}>Profile</Text>
          </View>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  scroll: { padding: 16, gap: 16 },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },
  noDataText: { color: "#6b7280", fontSize: 14, marginBottom: 16 },

  card: {
    borderRadius: 16,
    padding: 16,
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  cardTitle: { fontSize: 16, fontWeight: "600", color: "#0A364F" },
  cardText: { fontSize: 14, color: "#0A364F", marginTop: 4 },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
});
