import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Pressable, ScrollView, StyleSheet, Alert, ActivityIndicator } from "react-native";
import { Link } from "expo-router";

export default function AnimalInfo() {
  const [animals, setAnimals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [newAnimal, setNewAnimal] = useState({
    type: "",
    breed: "",
    dob: "",
    batch: "",
    notes: "",
  });

  useEffect(() => {
    const fetchAnimals = async () => {
      try {
        const res = await fetch("https://your-backend.com/api/farmer/animals");
        const data = await res.json();
        setAnimals(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    fetchAnimals();
  }, []);

  const handleAddAnimal = async () => {
    if (!newAnimal.type || !newAnimal.breed || !newAnimal.dob) {
      Alert.alert("Error", "Please fill all required fields (Type, Breed, DOB)");
      return;
    }

    try {
      const res = await fetch("https://your-backend.com/api/farmer/animals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newAnimal),
      });

      if (res.ok) {
        const addedAnimal = await res.json(); // Backend returns generated animal_id
        setAnimals([...animals, addedAnimal]);
        setNewAnimal({ type: "", breed: "", dob: "", batch: "", notes: "" });
        Alert.alert(
          "Success",
          `Animal added successfully!\nGenerated ID: ${addedAnimal.animal_id}`
        );
      } else {
        Alert.alert("Error", "Failed to add animal");
      }
    } catch (err) {
      console.error(err);
      Alert.alert("Error", "Something went wrong");
    }
  };

  if (loading) {
    return (
      <View style={styles.loading}>
        <ActivityIndicator size="large" color="#0A364F" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <Text style={styles.headerTxt}>My Livestock</Text>

        {/* Animal List */}
        {animals.length === 0 ? (
          <Text style={styles.noAnimalText}>No animals added yet</Text>
        ) : (
          animals.map((a, idx) => (
            <View key={idx} style={styles.card}>
              <Text style={styles.cardTitle}>{a.animal_id} ({a.type})</Text>
              <Text style={styles.cardText}>Breed: {a.breed}</Text>
              <Text style={styles.cardText}>DOB: {a.dob}</Text>
              {a.batch && <Text style={styles.cardText}>Batch: {a.batch}</Text>}
              {a.notes && <Text style={styles.cardText}>Notes: {a.notes}</Text>}
            </View>
          ))
        )}

        {/* Add New Animal Form */}
        <View style={styles.card}>
          <Text style={styles.safeTitle}>Add New Animal</Text>

          <TextInput
            placeholder="Type (Cow, Buffalo, etc.)"
            style={styles.input}
            value={newAnimal.type}
            onChangeText={(text) => setNewAnimal({ ...newAnimal, type: text })}
          />
          <TextInput
            placeholder="Breed"
            style={styles.input}
            value={newAnimal.breed}
            onChangeText={(text) => setNewAnimal({ ...newAnimal, breed: text })}
          />
          <TextInput
            placeholder="Date of Birth (YYYY-MM-DD)"
            style={styles.input}
            value={newAnimal.dob}
            onChangeText={(text) => setNewAnimal({ ...newAnimal, dob: text })}
          />
          <TextInput
            placeholder="Batch (optional)"
            style={styles.input}
            value={newAnimal.batch}
            onChangeText={(text) => setNewAnimal({ ...newAnimal, batch: text })}
          />
          <TextInput
            placeholder="Notes (optional)"
            style={styles.input}
            value={newAnimal.notes}
            onChangeText={(text) => setNewAnimal({ ...newAnimal, notes: text })}
          />

          <Pressable style={styles.submitBtn} onPress={handleAddAnimal}>
            <Text style={styles.submitTxt}>Add Animal</Text>
          </Pressable>
        </View>
      </ScrollView>

      {/* Footer */}
      <View style={styles.footer}>
        <Link href="/farmer" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.activeIcon}>🏠</Text>
            <Text style={styles.activeLabel}>Home</Text>
          </Pressable>
        </Link>
        <Link href="/farmer/dosage-log" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.icon}>📋</Text>
            <Text style={styles.label}>Log</Text>
          </Pressable>
        </Link>
        <Link href="/farmer/alerts" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.icon}>🔔</Text>
            <Text style={styles.label}>Alerts</Text>
          </Pressable>
        </Link>
        <Link href="/farmer/profile" asChild>
          <Pressable style={styles.footerItem}>
            <Text style={styles.icon}>👤</Text>
            <Text style={styles.label}>Profile</Text>
          </Pressable>
        </Link>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#E0F2E9" },
  scroll: { padding: 16, gap: 16 },
  headerTxt: { fontSize: 18, fontWeight: "bold", color: "#0A364F" },
  noAnimalText: { color: "#6b7280", fontSize: 14, marginBottom: 16 },

  card: {
    backgroundColor: "white",
    borderRadius: 16,
    padding: 20,
    shadowOpacity: 0.1,
    shadowRadius: 3,
  },
  cardTitle: { fontSize: 16, fontWeight: "600", color: "#0A364F" },
  cardText: { fontSize: 14, color: "#6b7280", marginTop: 4 },

  safeTitle: { fontSize: 16, fontWeight: "600", color: "#0A364F", marginBottom: 12 },
  input: {
    marginTop: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    fontSize: 16,
    color: "#0A364F",
  },

  submitBtn: {
    backgroundColor: "#0A364F",
    borderRadius: 9999,
    paddingVertical: 16,
    marginTop: 16,
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  submitTxt: { textAlign: "center", color: "white", fontWeight: "bold", fontSize: 16 },

  footer: {
    flexDirection: "row",
    justifyContent: "space-around",
    paddingVertical: 10,
    borderTopWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "white",
  },
  footerItem: { alignItems: "center" },
  icon: { fontSize: 18, color: "#9ca3af" },
  label: { fontSize: 12, color: "#9ca3af" },
  activeIcon: { fontSize: 18, color: "#0A364F" },
  activeLabel: { fontSize: 12, color: "#0A364F", fontWeight: "600" },

  loading: { flex: 1, justifyContent: "center", alignItems: "center" },
});
