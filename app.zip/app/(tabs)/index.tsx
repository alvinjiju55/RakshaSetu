import React from "react";
import { View, Text, TouchableOpacity, Platform, StyleSheet } from "react-native";
import { Link } from "expo-router";
import { MaterialIcons } from "@expo/vector-icons";
import AppLoading from "expo-app-loading";
import { useFonts, Lexend_500Medium, Lexend_700Bold } from "@expo-google-fonts/lexend";
import { NotoSans_400Regular } from "@expo-google-fonts/noto-sans";

const roles = [
  { name: "Livestock Farmer", icon: "agriculture", href: "/farmer" as const },
  { name: "Veterinary Doctor", icon: "ecg_heart", href: "/vet" as const },
  { name: "Collection Center", icon: "local_shipping", href: "/collection" as const },
  { name: "Regulator", icon: "gavel", href: "/regulator" as const },
];

export default function Dashboard() {
  const [fontsLoaded] = useFonts({
    Lexend_500Medium,
    Lexend_700Bold,
    NotoSans_400Regular,
  });

  if (!fontsLoaded) return <AppLoading />;

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={[styles.headerText, { fontFamily: "Lexend_700Bold" }]}>RakshaSetu</Text>
      </View>

      {/* Main */}
      <View style={styles.main}>
        <Text style={[styles.title, { fontFamily: "Lexend_700Bold" }]}>Welcome to RakshaSetu</Text>
        <Text style={[styles.subtitle, { fontFamily: "NotoSans_400Regular" }]}>
          Select your role to continue
        </Text>

        <View style={styles.buttonContainer}>
          {roles.map((role) => (
            <Link key={role.name} href={role.href} asChild>
              <TouchableOpacity
                style={styles.roleButton}
                activeOpacity={0.7}
              >
                <MaterialIcons name={role.icon as any} size={24} color="#0d1b0d" />
                <Text style={[styles.roleText, { fontFamily: "Lexend_500Medium" }]}>{role.name}</Text>
              </TouchableOpacity>
            </Link>
          ))}
        </View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <Text style={[styles.footerText, { fontFamily: "NotoSans_400Regular" }]}>
          By continuing, you agree to our{" "}
          <Text style={{ color: "#22c55e", fontFamily: "Lexend_500Medium" }}>Terms of Service</Text> and{" "}
          <Text style={{ color: "#22c55e", fontFamily: "Lexend_500Medium" }}>Privacy Policy</Text>
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "space-between", backgroundColor: "#f8fcf8", padding: 16 },
  header: { alignItems: "center", padding: 16, backgroundColor: "#ffffff", shadowColor: "#000", shadowOpacity: 0.1, shadowOffset: { width: 0, height: 2 }, shadowRadius: 4, borderBottomLeftRadius: 16, borderBottomRightRadius: 16 },
  headerText: { fontSize: 20, fontWeight: "bold" },
  main: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 28, color: "#0d1b0d", marginBottom: 4, textAlign: "center" },
  subtitle: { fontSize: 16, color: "#6b7280", marginBottom: 24, textAlign: "center" },
  buttonContainer: { width: "100%", maxWidth: 360 },
  roleButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    height: 56,
    marginBottom: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#d1d5db",
    backgroundColor: "#ffffff",
    shadowColor: "#000",
    shadowOpacity: 0.05,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    // Hover effect for web
    ...(Platform.OS === "web" ? { transitionDuration: "200ms" } : {}),
  },
  roleText: { marginLeft: 12, fontSize: 16, fontWeight: "600", color: "#0d1b0d" },
  footer: { padding: 16 },
  footerText: { fontSize: 12, color: "#6b7280", textAlign: "center" },
});
